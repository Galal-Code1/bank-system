setx forms60_path "D:\bank system"
imp system/mbs@mbs file=D:\bank_system\db_bank.dmp